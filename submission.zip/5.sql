-- 5.sql: The average energy of all the songs.
SELECT AVG(energy) AS average_energy
FROM songs;
